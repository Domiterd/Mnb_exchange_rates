@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.mnb.hu/webservices/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package hu.mnb.webservices;
