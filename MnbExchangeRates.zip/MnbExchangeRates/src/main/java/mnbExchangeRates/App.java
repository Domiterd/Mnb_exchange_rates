package mnbExchangeRates;
import java.io.StringReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.tempuri.MNBArfolyamServiceSoap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class App {

    public static void main(String[] args) {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        factory.setServiceClass(MNBArfolyamServiceSoap.class);
        factory.setAddress("http://www.mnb.hu/arfolyamok.asmx");

        MNBArfolyamServiceSoap client = (MNBArfolyamServiceSoap) factory.create();

    
        Client proxy = ClientProxy.getClient(client);
        HTTPConduit conduit = (HTTPConduit) proxy.getConduit();
        HTTPClientPolicy policy = new HTTPClientPolicy();
        policy.setConnectionTimeout(3000);
        policy.setReceiveTimeout(3000);
        conduit.setClient(policy);

     
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusYears(2);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy.MM.dd");
        String startDateStr = startDate.format(formatter);
        String endDateStr = endDate.format(formatter);	

        try {
            String response = client.getExchangeRates(startDateStr, endDateStr,"EUR");
        
            DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory1.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(response)));

            NodeList rates = document.getElementsByTagName("Day");
            for (int i = 0; i < rates.getLength(); i++) {
                Element rate = (Element) rates.item(i);
                String date = rate.getAttribute("date");
                String value = rate.getTextContent();
                System.out.println("D�tum: " + date + ", Euro napi �rfolyam: " + value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
